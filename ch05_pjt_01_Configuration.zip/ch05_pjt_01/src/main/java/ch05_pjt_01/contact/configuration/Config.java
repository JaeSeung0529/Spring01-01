package ch05_pjt_01.contact.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import ch05_pjt_01.contact.dao.ContactDao;
import ch05_pjt_01.contact.service.ContactRegisterService;
import ch05_pjt_01.contact.service.ContactSearchService;
import ch05_pjt_01.contact.utils.InitSampleData;

@Configuration
public class Config {

	
//		<bean id="initSampleData" class="ch05_pjt_01.contact.utils.InitSampleData">
//		<property name="names">
//			<array>
//				<value>류현진</value>
//				<value>손흥민</value>
//				<value>김연경</value>
//			</array>
//		</property>
//		<property name="phoneNumbers">
//			<array>
//				<value>010-0000-1111</value>
//				<value>010-0000-2222</value>
//				<value>010-0000-3333</value>
//			</array>
//		</property>
//	</bean>
	

	@Bean
	public InitSampleData initSampleData() {
		 InitSampleData initSampleData = new InitSampleData();
	        
	        String[] names = {"류현진", "손흥민", "김연경"};
	        initSampleData.setNames(names);
	        
	        String[] phoneNumbers = {"010-0000-1111", "010-0000-2222", "010-0000-3333"};
	        initSampleData.setPhoneNumbers(phoneNumbers);
	        
	        return initSampleData;
		
	}
	
//
//	<bean id="contactDao" class="ch05_pjt_01.contact.dao.ContactDao" />
	
	@Bean
	public ContactDao contactDao() {
		return new ContactDao();
	}
//		
//	<bean id="registerService" class="ch05_pjt_01.contact.service.ContactRegisterService">
//	<!--	<constructor-arg ref="contactDao" />   -->
//		
//	</bean>
	@Bean
	public ContactRegisterService registerService() {
		return new ContactRegisterService();
	}
	
//	
//	<bean id="searchService" class="ch05_pjt_01.contact.service.ContactSearchService">
//	<!--	<constructor-arg ref="contactDao" />   -->
//		
//	</bean>
	
	@Bean 
	public ContactSearchService searchService() {
		return new ContactSearchService();
	}

}
