package com.office.library.admin.member;

import org.springframework.stereotype.Component;

@Component //@Repositiory �� ������
public class AdminMemberDao {
	public boolean isAdminMember(String a_m_id)
	{
		System.out.println(
			"AdminMemberDao�� isAdminMember()ȣ���");
		return true;
	}

}
