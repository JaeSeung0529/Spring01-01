package com.office.library.admin.member;

import org.springframework.stereotype.Component;

@Component //@Repositiory도 가능함
public class AdminMemberDao {
	public boolean isAdminMember(String a_m_id) {
	
		System.out.println("AdminMemberDao의 isAdminMember()호출됨");
		return true;
	}
}
